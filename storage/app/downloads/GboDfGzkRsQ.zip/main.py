"""
Main script that demonstrates OCR using easyocr. It imports easyocr, creates a reader for English, reads an image (e.g., 'images/good1.jpeg'), prints the raw result (bounding boxes, text, confidence), and then iterates over results to print only the text. It also includes a function 'is_text_present(image_path)' that returns True if the result list length > 0, and demonstrates its use on sample images.
Extracted from YouTube tutorial by YouExtractor
"""

import easyocr

# Initialize the reader for English language
reader = easyocr.Reader(['en'])

# Function to check if text is present in an image
def is_text_present(image_path):
    result = reader.readtext(image_path)
    # Return True if any text segments were found
    return len(result) > 0

# Example usage with good1.jpeg
print("Reading good1.jpeg...")
result = reader.readtext('images/good1.jpeg')
print("Raw result (bounding boxes, text, confidence):")
print(result)
print("\nExtracted text only:")
for (bbox, text, prob) in result:
    print(text)

print("\n" + "="*50 + "\n")

# Example usage with good2.png
print("Reading good2.png...")
result = reader.readtext('images/good2.png')
print("Raw result:")
print(result)
print("\nExtracted text only:")
for (bbox, text, prob) in result:
    print(text)

print("\n" + "="*50 + "\n")

# Example usage with bad1.jpeg
print("Reading bad1.jpeg...")
result = reader.readtext('images/bad1.jpeg')
print("Raw result:")
print(result)
print("\nExtracted text only:")
for (bbox, text, prob) in result:
    print(text)

print("\n" + "="*50 + "\n")

# Example usage with bad2.jpeg
print("Reading bad2.jpeg...")
result = reader.readtext('images/bad2.jpeg')
print("Raw result:")
print(result)
print("\nExtracted text only:")
for (bbox, text, prob) in result:
    print(text)

print("\n" + "="*50 + "\n")

# Demonstrate is_text_present function
print("Testing is_text_present function:")
print("good1.jpeg:", is_text_present('images/good1.jpeg'))
print("good2.png:", is_text_present('images/good2.png'))
print("bad1.jpeg:", is_text_present('images/bad1.jpeg'))
print("bad2.jpeg:", is_text_present('images/bad2.jpeg'))
