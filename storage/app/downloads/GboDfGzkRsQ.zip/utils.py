"""
Contains helper functions such as 'extract_text_from_image(image_path)' which returns a list of detected text strings, and 'is_text_present(image_path, min_characters=0)' which returns True if the total number of characters in detected text exceeds min_characters.
Extracted from YouTube tutorial by YouExtractor
"""

import easyocr

# Initialize the reader globally to avoid re-initialization
_reader = None

def get_reader():
    global _reader
    if _reader is None:
        _reader = easyocr.Reader(['en'])
    return _reader

def extract_text_from_image(image_path):
    """
    Extract text from an image using easyocr.
    
    Args:
        image_path (str): Path to the image file.
    
    Returns:
        list: A list of detected text strings.
    """
    reader = get_reader()
    result = reader.readtext(image_path)
    texts = [text for (bbox, text, prob) in result]
    return texts

def is_text_present(image_path, min_characters=0):
    """
    Check if text is present in an image.
    
    Args:
        image_path (str): Path to the image file.
        min_characters (int): Minimum number of characters required to consider text present.
    
    Returns:
        bool: True if text is present (with at least min_characters), False otherwise.
    """
    texts = extract_text_from_image(image_path)
    total_chars = sum(len(t) for t in texts)
    return total_chars > min_characters
