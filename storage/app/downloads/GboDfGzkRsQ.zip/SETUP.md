# Setup Instructions

```bash
1. Install Python 3.6 or higher. 2. Create a virtual environment (optional but recommended). 3. Install dependencies: pip install -r requirements.txt. 4. Place sample images in the 'images' folder. 5. Run main.py to see OCR results.
```