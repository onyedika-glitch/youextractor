// Project documentation including overview, setup instructions, usage examples, and explanation of the code in main.py.
// Extracted from YouTube tutorial by YouExtractor

# Simple OCR in Python with easyocr

This project demonstrates a simple way to perform Optical Character Recognition (OCR) in Python using the `easyocr` library. It can extract text from images and check if text is present in an image.

## Setup

1. Clone this repository.
2. Install the required dependencies:

```bash
pip install -r requirements.txt
```

Note: `easyocr` will automatically download the pre-trained model on first use.

## Usage

Run the main script:

```bash
python main.py
```

The script will:
- Initialize an easyocr reader for English.
- Read sample images from the `images/` directory.
- Print raw results (bounding boxes, text, confidence).
- Print only the extracted text.
- Demonstrate the `is_text_present` function.

## Sample Images

- `images/good1.jpeg`: Clear text (Shakespeare quote).
- `images/good2.png`: Sale banners with clear text.
- `images/bad1.jpeg`: Skewed/rotated text (messy sign).
- `images/bad2.jpeg`: Difficult text ("two hour hone" and "welcome").

## Functions

### `is_text_present(image_path)`
Returns `True` if any text segments are detected in the image, `False` otherwise.

## Notes

- This is a simple OCR solution; results may not be perfect, especially with skewed or low-quality images.
- For better accuracy, consider using more advanced models like GPT-based solutions.
