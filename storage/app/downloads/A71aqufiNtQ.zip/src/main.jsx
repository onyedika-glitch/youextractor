/**
 * The JavaScript entry point that imports React, ReactDOM, and the root App component, mounting it directly to the DOM's root element.
 * Extracted from YouTube tutorial by YouExtractor
 */

import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)