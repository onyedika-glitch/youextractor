/**
 * The root component of the application. It manages the global state of tasks, handles API calls (fetching, adding, deleting, and toggling reminders) to the json-server, and coordinates the layout of the Header, AddTask, and Tasks components.
 * Extracted from YouTube tutorial by YouExtractor
 */

import { useState, useEffect } from 'react'
import Header from './components/Header'
import Tasks from './components/Tasks'
import AddTask from './components/AddTask'

function App() {
  const [showAddTask, setShowAddTask] = useState(false)
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const getTasks = async () => {
      try {
        const tasksFromServer = await fetchTasks()
        setTasks(tasksFromServer)
      } catch (err) {
        setError('Failed to fetch tasks. Make sure json-server is running on port 5000.')
      } finally {
        setLoading(false)
      }
    }

    getTasks()
  }, [])

  // Fetch Tasks
  const fetchTasks = async () => {
    const res = await fetch('/api/tasks')
    if (!res.ok) {
      throw new Error('Error fetching data')
    }
    const data = await res.json()
    return data
  }

  // Fetch Single Task
  const fetchTask = async (id) => {
    const res = await fetch(`/api/tasks/${id}`)
    const data = await res.json()
    return data
  }

  // Add Task
  const addTask = async (task) => {
    try {
      const res = await fetch('/api/tasks', {
        method: 'POST',
        headers: {
          'Content-type': 'application/json',
        },
        body: JSON.stringify(task),
      })

      const data = await res.json()
      setTasks([...tasks, data])
    } catch (err) {
      alert('Error adding task')
    }
  }

  // Delete Task
  const deleteTask = async (id) => {
    try {
      const res = await fetch(`/api/tasks/${id}`, {
        method: 'DELETE',
      })

      if (res.status === 200 || res.ok) {
        setTasks(tasks.filter((task) => task.id !== id))
      } else {
        alert('Error deleting this task')
      }
    } catch (err) {
      alert('Error deleting task')
    }
  }

  // Toggle Reminder
  const toggleReminder = async (id) => {
    try {
      const taskToToggle = await fetchTask(id)
      const updTask = { ...taskToToggle, reminder: !taskToToggle.reminder }

      const res = await fetch(`/api/tasks/${id}`, {
        method: 'PUT',
        headers: {
          'Content-type': 'application/json',
        },
        body: JSON.stringify(updTask),
      })

      const data = await res.json()

      setTasks(
        tasks.map((task) =>
          task.id === id ? { ...task, reminder: data.reminder } : task
        )
      )
    } catch (err) {
      alert('Error updating task reminder')
    }
  }

  return (
    <div className="container mx-auto max-w-lg mt-10 p-6 bg-white rounded-xl shadow-lg border border-slate-200">
      <Header
        title="Task Tracker"
        onAdd={() => setShowAddTask(!showAddTask)}
        showAdd={showAddTask}
      />
      
      {showAddTask && <AddTask onAdd={addTask} />}
      
      {loading ? (
        <div className="text-center py-10 text-slate-500">Loading tasks...</div>
      ) : error ? (
        <div className="bg-red-50 text-red-600 p-4 rounded-lg border border-red-200 my-4 text-sm text-center">
          {error}
        </div>
      ) : tasks.length > 0 ? (
        <Tasks
          tasks={tasks}
          onDelete={deleteTask}
          onToggle={toggleReminder}
        />
      ) : (
        <div className="text-center py-10 text-slate-400 italic">
          No Tasks To Show. Double-click tasks to toggle reminder.
        </div>
      )}
    </div>
  )
}

export default App