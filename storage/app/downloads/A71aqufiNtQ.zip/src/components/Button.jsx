/**
 * A highly reusable button component that accepts color, text, and an onClick event handler as props to ensure UI consistency.
 * Extracted from YouTube tutorial by YouExtractor
 */

import PropTypes from 'prop-types'

const Button = ({ color, text, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-lg text-white font-medium text-sm transition-colors duration-200 shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${color}`}
    >
      {text}
    </button>
  )
}

Button.defaultProps = {
  color: 'bg-indigo-600 hover:bg-indigo-700',
}

Button.propTypes = {
  text: PropTypes.string.isRequired,
  color: PropTypes.string,
  onClick: PropTypes.func,
}

export default Button