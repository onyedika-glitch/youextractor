/**
 * Displays an individual task item. It features a double-click event to toggle the reminder state (visualized by a green border) and a delete icon button using Lucide React.
 * Extracted from YouTube tutorial by YouExtractor
 */

import PropTypes from 'prop-types'
import { X } from 'lucide-react'

const Task = ({ task, onDelete, onToggle }) => {
  return (
    <div
      onDoubleClick={() => onToggle(task.id)}
      className={`task-item flex justify-between items-center p-4 rounded-lg border bg-slate-50 cursor-pointer transition-all duration-200 ${
        task.reminder
          ? 'border-l-4 border-l-emerald-500 border-slate-200 shadow-sm'
          : 'border-slate-200'
      }`}
    >
      <div>
        <h3 className="font-semibold text-slate-800 text-base">{task.text}</h3>
        {task.day && <p className="text-xs text-slate-500 mt-1">{task.day}</p>}
      </div>
      <button
        onClick={(e) => {
          e.stopPropagation()
          onDelete(task.id)
        }}
        className="text-slate-400 hover:text-red-500 p-1.5 rounded-full hover:bg-red-50 transition-colors duration-150"
        title="Delete Task"
      >
        <X size={18} />
      </button>
    </div>
  )
}

Task.propTypes = {
  task: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    text: PropTypes.string.isRequired,
    day: PropTypes.string,
    reminder: PropTypes.bool,
  }).isRequired,
  onDelete: PropTypes.func.isRequired,
  onToggle: PropTypes.func.isRequired,
}

export default Task