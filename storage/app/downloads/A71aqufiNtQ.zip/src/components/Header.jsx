/**
 * Renders the application header, including the title and a toggle button to show/hide the AddTask form. It receives props to control the button's appearance and click handler.
 * Extracted from YouTube tutorial by YouExtractor
 */

import PropTypes from 'prop-types'
import Button from './Button'

const Header = ({ title, onAdd, showAdd }) => {
  return (
    <header className="flex justify-between items-center mb-6 pb-4 border-b border-slate-100">
      <h1 className="text-2xl font-bold text-slate-800">{title}</h1>
      <Button
        color={showAdd ? 'bg-red-500 hover:bg-red-600' : 'bg-indigo-600 hover:bg-indigo-700'}
        text={showAdd ? 'Close' : 'Add Task'}
        onClick={onAdd}
      />
    </header>
  )
}

Header.defaultProps = {
  title: 'Task Tracker',
}

Header.propTypes = {
  title: PropTypes.string.isRequired,
  onAdd: PropTypes.func.isRequired,
  showAdd: PropTypes.bool.isRequired,
}

export default Header