/**
 * A controlled form component that manages local state for task text, day/time, and reminder status. It validates user inputs and triggers an onAdd callback passed from App.jsx.
 * Extracted from YouTube tutorial by YouExtractor
 */

import { useState } from 'react'
import PropTypes from 'prop-types'

const AddTask = ({ onAdd }) => {
  const [text, setText] = useState('')
  const [day, setDay] = useState('')
  const [reminder, setReminder] = useState(false)

  const onSubmit = (e) => {
    e.preventDefault()

    if (!text) {
      alert('Please add a task description')
      return
    }

    onAdd({ text, day, reminder })

    setText('')
    setDay('')
    setReminder(false)
  }

  return (
    <form onSubmit={onSubmit} className="mb-8 bg-slate-55 p-4 rounded-lg border border-slate-200 space-y-4">
      <div className="flex flex-col">
        <label className="text-sm font-semibold text-slate-700 mb-1">Task</label>
        <input
          type="text"
          placeholder="Add Task Description"
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
        />
      </div>
      
      <div className="flex flex-col">
        <label className="text-sm font-semibold text-slate-700 mb-1">Day & Time</label>
        <input
          type="text"
          placeholder="Add Day & Time (e.g. Feb 5th at 2:30pm)"
          value={day}
          onChange={(e) => setDay(e.target.value)}
          className="px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
        />
      </div>
      
      <div className="flex items-center justify-between py-2">
        <label className="text-sm font-semibold text-slate-700">Set Reminder</label>
        <input
          type="checkbox"
          checked={reminder}
          onChange={(e) => setReminder(e.currentTarget.checked)}
          className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-slate-300 rounded"
        />
      </div>

      <input
        type="submit"
        value="Save Task"
        className="w-full bg-slate-800 hover:bg-slate-900 text-white font-medium py-2 rounded-lg cursor-pointer transition-colors duration-200 text-sm shadow-sm"
      />
    </form>
  )
}

AddTask.propTypes = {
  onAdd: PropTypes.func.isRequired,
}

export default AddTask