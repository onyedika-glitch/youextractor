/**
 * Configures PostCSS to run Tailwind CSS and Autoprefixer during the build process.
 * Extracted from YouTube tutorial by YouExtractor
 */

export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}