/**
 * Configures Tailwind CSS utility classes, defining content paths to scan for React components to ensure unused styles are purged in production.
 * Extracted from YouTube tutorial by YouExtractor
 */

/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}