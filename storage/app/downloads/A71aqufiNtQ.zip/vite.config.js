/**
 * Configures the Vite build tool, including the React plugin and custom server port settings to avoid conflicts with the mock backend.
 * Extracted from YouTube tutorial by YouExtractor
 */

import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
})