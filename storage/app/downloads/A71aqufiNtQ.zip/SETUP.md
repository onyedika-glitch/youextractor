# Setup Instructions

```bash
To set up this project, ensure you have Node.js installed. Create a project directory, initialize it, install the dependencies listed in package.json, configure Tailwind CSS, and set up the mock database file. You can then run both the React development server and the json-server mock backend simultaneously.
```