// Project documentation and setup instructions
// Extracted from YouTube tutorial

# Full Stack Web Development App

## Setup Instructions

1. Clone the repository.
2. Navigate to the project directory.
3. Run `npm install` to install dependencies.
4. Start MongoDB server.
5. Run `node server.js` to start the server.
6. Navigate to `client` directory and run `npm start` to start the React application.

## Docker Setup

Run `docker-compose up` to start the application with Docker.