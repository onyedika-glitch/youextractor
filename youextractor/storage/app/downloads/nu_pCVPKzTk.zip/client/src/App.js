/**
 * Main React application component
 * Extracted from YouTube tutorial
 */

import React from 'react';
import './App.css';

function App() {
    return (
        <div className="App">
            <h1>Full Stack Web Development</h1>
        </div>
    );
}

export default App;