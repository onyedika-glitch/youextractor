# Setup Instructions

```bash
npm install
node server.js
```