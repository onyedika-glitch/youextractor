# Setup Instructions

```bash
pip install -r requirements.txt
flask run
```