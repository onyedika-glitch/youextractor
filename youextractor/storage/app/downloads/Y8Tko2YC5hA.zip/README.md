// Project documentation explaining how to set up and run the application.
// Extracted from YouTube tutorial

# Python Flask App

This is a simple Flask web application demonstrating the popularity of Python.

## Setup

1. Install Python 3.7+
2. Clone this repository
3. Install dependencies using `pip install -r requirements.txt`
4. Run the application using `flask run`