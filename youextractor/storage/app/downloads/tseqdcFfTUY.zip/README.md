// Project setup and deployment instructions
// Extracted from YouTube tutorial

# Patient Management System

## Overview
This is a production-ready patient management system built with Java Spring Boot and deployed using AWS.

## Setup Instructions
1. Clone the repository.
2. Navigate to the project directory.
3. Run `mvn clean install` to build the project.
4. Use `docker-compose up` to start the application and database.
5. Access the application at `http://localhost:8080/api/patients`.