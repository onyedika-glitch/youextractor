# Setup Instructions

```bash
mvn clean install
docker-compose up
```