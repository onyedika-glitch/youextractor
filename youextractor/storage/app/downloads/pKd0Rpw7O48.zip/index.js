/**
 * Main entry point of the application.
 * Extracted from YouTube tutorial
 */

const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.get('/api/items', (req, res) => {
    res.send([]);
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});