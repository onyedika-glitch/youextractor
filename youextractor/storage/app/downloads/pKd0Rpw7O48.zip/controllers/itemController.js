/**
 * Controller for handling item logic.
 * Extracted from YouTube tutorial
 */

const items = [];

exports.getItems = (req, res) => {
    res.json(items);
};

exports.createItem = (req, res) => {
    const item = req.body;
    items.push(item);
    res.status(201).json(item);
};