// Project documentation.
// Extracted from YouTube tutorial

# REST API with Node.js and Express

This project demonstrates how to build a REST API using Node.js and Express.