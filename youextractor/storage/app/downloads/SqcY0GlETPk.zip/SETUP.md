# Setup Instructions

```bash
npx create-react-app my-app
cd my-app
npm start
```