# Setup Instructions

```bash
npm install
npm start
```