/**
 * User model for MongoDB using Mongoose.
 * Extracted from YouTube tutorial
 */

const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    name: String,
    email: String
});

module.exports = mongoose.model('User', userSchema);