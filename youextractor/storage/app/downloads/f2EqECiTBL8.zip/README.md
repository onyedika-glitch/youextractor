// Project documentation and instructions.
// Extracted from YouTube tutorial

# Node.js Full Course

This is a complete Node.js application built using Express and MongoDB.

## Getting Started

1. Install Node.js and MongoDB.
2. Clone the repository.
3. Run `npm install` to install dependencies.
4. Start the server with `npm run dev`.