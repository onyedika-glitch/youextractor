# Setup Instructions

```bash
npm install
npm run dev
```