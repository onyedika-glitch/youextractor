/**
 * Error handling middleware.
 * Extracted from YouTube tutorial
 */

module.exports = (err, req, res, next) => {
    res.status(500).send({ error: err.message });
};