/**
 * Primary JavaScript file containing all tutorial code: console methods, variables, data types, strings, arrays, objects, JSON, loops, conditionals, functions, and DOM manipulation.
 * Extracted from YouTube tutorial by YouExtractor
 */

// Console methods
console.log('Hello World');
console.error('This is an error');
console.warn('This is a warning');

// Variables
let age = 30;
console.log(age);
age = 31;
console.log(age);

let score;
score = 10;
console.log(score);

const name = 'John';
const isCool = true;
const rating = 4.5;
const x = null;
const y = undefined;
let z;

console.log(typeof name);
console.log(typeof age);
console.log(typeof rating);
console.log(typeof isCool);
console.log(typeof x);
console.log(typeof y);
console.log(typeof z);

// String concatenation
console.log('My name is ' + name + ' and I am ' + age);

// Template literals
const hello = `My name is ${name} and I am ${age}`;
console.log(hello);

// String properties and methods
const s = 'Hello World';
console.log(s.length);
console.log(s.toUpperCase());
console.log(s.toLowerCase());
console.log(s.substring(0, 5));
console.log(s.substring(0, 5).toUpperCase());
console.log(s.split(''));
console.log(s.split(', '));

// Arrays
const numbers = new Array(1, 2, 3, 4, 5);
console.log(numbers);

const fruits = ['apples', 'oranges', 'pears'];
console.log(fruits);
console.log(fruits[1]);
fruits[3] = 'grapes';
console.log(fruits);
fruits.push('mangoes');
console.log(fruits);
fruits.unshift('strawberries');
console.log(fruits);
fruits.pop();
console.log(fruits);
console.log(Array.isArray(fruits));
console.log(fruits.indexOf('oranges'));

// Object literals
const person = {
    firstName: 'John',
    lastName: 'Doe',
    age: 30,
    hobbies: ['music', 'movies', 'sports'],
    address: {
        street: '50 Main St',
        city: 'Boston',
        state: 'MA'
    }
};

console.log(person);
console.log(person.firstName, person.lastName);
console.log(person.hobbies[1]);
console.log(person.address.city);

// Destructuring
const { firstName, lastName, address: { city } } = person;
console.log(firstName);
console.log(city);

// Adding properties
person.email = 'john@gmail.com';
console.log(person);

// Array of objects
const todos = [
    {
        id: 1,
        text: 'Take out trash',
        isCompleted: true
    },
    {
        id: 2,
        text: 'Meeting with boss',
        isCompleted: true
    },
    {
        id: 3,
        text: 'Dentist appointment',
        isCompleted: false
    }
];

console.log(todos);
console.log(todos[1].text);

// JSON
const todoJSON = JSON.stringify(todos);
console.log(todoJSON);

// For loop
for (let i = 0; i < 10; i++) {
    console.log(`For Loop Number: ${i}`);
}

// While loop
let i = 0;
while (i < 10) {
    console.log(`While Loop Number: ${i}`);
    i++;
}

// Loop through arrays
for (let i = 0; i < todos.length; i++) {
    console.log(todos[i].text);
}

// For...of loop
for (let todo of todos) {
    console.log(todo.text);
}

// High order array methods
// forEach
todos.forEach(function(todo) {
    console.log(todo.text);
});

// map
const todoText = todos.map(function(todo) {
    return todo.text;
});
console.log(todoText);

// filter
const todoCompleted = todos.filter(function(todo) {
    return todo.isCompleted === true;
}).map(function(todo) {
    return todo.text;
});
console.log(todoCompleted);

// Conditionals
const xVal = 10;
if (xVal === 10) {
    console.log('x is 10');
} else if (xVal > 10) {
    console.log('x is greater than 10');
} else {
    console.log('x is less than 10');
}

// Multiple conditions
const yVal = 10;
if (xVal > 5 || yVal > 10) {
    console.log('x is more than 5 or y is more than 10');
}

if (xVal > 5 && yVal > 10) {
    console.log('x is more than 5 and y is more than 10');
}

// Ternary operator
const xNum = 10;
const color = xNum > 10 ? 'red' : 'blue';
console.log(color);

// Switch statement
switch (color) {
    case 'red':
        console.log('color is red');
        break;
    case 'blue':
        console.log('color is blue');
        break;
    default:
        console.log('color is not red or blue');
        break;
}

// Functions
function addNums(num1 = 1, num2 = 1) {
    return num1 + num2;
}
console.log(addNums(5, 4));
console.log(addNums());

// Arrow function
const addNumsArrow = (num1 = 1, num2 = 1) => num1 + num2;
console.log(addNumsArrow(5, 4));

// DOM manipulation
const button = document.getElementById('myButton');
const outputDiv = document.getElementById('output');

button.addEventListener('click', function(e) {
    outputDiv.textContent = 'Button was clicked!';
});

// Form validation
const form = document.getElementById('myForm');
const nameInput = document.getElementById('nameInput');
const formOutput = document.getElementById('formOutput');

form.addEventListener('submit', function(e) {
    e.preventDefault();
    const nameValue = nameInput.value;
    if (nameValue === '') {
        formOutput.textContent = 'Please enter a name.';
        formOutput.style.color = 'red';
    } else {
        formOutput.textContent = `Hello, ${nameValue}!`;
        formOutput.style.color = 'green';
    }
});