# Setup Instructions

```bash
1. Create a new folder for the project. 2. Inside the folder, create the three files: index.html, main.js, and style.css. 3. Copy the provided code into each file. 4. Open the folder in Visual Studio Code. 5. Install the Live Server extension if not already installed. 6. Right-click on index.html and select 'Open with Live Server'. The browser will open and auto-reload on file changes.
```